START TRANSACTION;

CREATE TABLE `account` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `admin` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE `admin` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `email` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE `orderHis` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE `post` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `imgName` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `status` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `account` (`id`, `email`, `password`, `admin`) VALUES
(7, 'admin@admin.test', 'adm123', 1);

INSERT INTO `admin` (`id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', '1212');

INSERT INTO `post` (`id`, `imgName`, `name`, `price`, `status`) VALUES

ALTER TABLE `account` AUTO_INCREMENT = 10;
ALTER TABLE `admin` AUTO_INCREMENT = 2;
ALTER TABLE `orderHis` AUTO_INCREMENT = 54;
ALTER TABLE `post` AUTO_INCREMENT = 111178;

COMMIT;