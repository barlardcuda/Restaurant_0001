import { Request, Response } from 'express'
import db from './db'
import { myRes } from './myRes'
import { createWriteStream, existsSync, mkdirSync } from 'fs'
import path from 'path'
import escpos from 'escpos'

interface CartItem {
    id: string
    name: string
    quantity: number
    price: number
}

escpos.USB = require('escpos-usb')

export async function Order(req: Request, res: Response) {
    if (!req.session.account) {
        return res.redirect('/login.html')
    }

    const cart: CartItem[] = req.body
    const user = req.session.account

    try {
        await db.execute('INSERT INTO orderHis (user, data) VALUES (?, ?)', [user, JSON.stringify(cart)])

        const receiptData = createReceipt(user, cart)
        console.log(receiptData)

        const receiptDir = path.join(__dirname, 'receipts')
        if (!existsSync(receiptDir)) {
            mkdirSync(receiptDir)
        }

        const receiptPath = path.join(receiptDir, `receipt_${Date.now()}.txt`)
        const stream = createWriteStream(receiptPath)
        stream.write(receiptData)
        stream.end()

        res.status(200).json(myRes(1, "ການຊື້ສຳເລັດ"))

        printReceipt(receiptData)

    } catch (error) {
        res.status(500).json(myRes(0, "ການຊືເກີດຂໍ້ຜິດພາດ"))
    }
}

function createReceipt(user: string, cart: CartItem[]): string {
    let receipt = ''
    receipt += '           ບິນສຳລັບການຊື້ສິນຄ້າ\n'
    receipt += '--------------------------------------------\n'
    receipt += `ລູກຄ້າ: ${user}\n`
    receipt += 'ວັນທີ: ' + new Date().toLocaleString() + '\n'
    receipt += '--------------------------------------------\n'
    receipt += 'ລາຍການ               ຈຳນວນ      ລາຄາ\n'
    receipt += '--------------------------------------------\n'

    cart.forEach(item => {
        const itemName = `${item.name}`
        receipt += `${itemName.padEnd(20)} ${item.quantity.toString().padEnd(10)} ${(item.price * item.quantity).toLocaleString()} ກີບ\n`
    })

    receipt += '--------------------------------------------\n'
    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
    receipt += `ລວມທັງໝົດ: ${total.toLocaleString()} ກີບ\n`
    receipt += '--------------------------------------------\n'
    receipt += '       ຂອບໃຈທີ່ທ່ານໄດ້ຊື້ສິນຄ້າຂອງເຮົາ!\n'
    receipt += '============================================\n'

    return receipt
}

function printReceipt(receiptData: string) {
    try {
        const device = new escpos.USB()
        const printer = new escpos.Printer(device)

        device.open(() => {
            printer
                .align('CT')
                .style('B')
                .text('ບິນສຳລັບການຊື້ສິນຄ້າ')
                .text('------------------------------------------')
                .style('NORMAL')
                .text(receiptData)
                .cut()
                .close()
        })
    } catch (error) {
        console.log('Error printing receipt:', error)
    }
}
